x = int(input("Enter 1 if you are a human : "))
if x==1:
    print("Siddharth is a very Cute boy !! You must have a crush on him.")
else:
    print("You are an idiot, Run again and Enter 1 !!")
